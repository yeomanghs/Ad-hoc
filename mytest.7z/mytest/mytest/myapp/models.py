from django.db import models

COLOR_CHOICES = (
    ('blue', 'BLUE'),
    ('red','RED'),
    ('yellow','YELLOW'),
)

class MyModel(models.Model):
  name = models.CharField(max_length = 100, default = None)
  color = models.CharField(max_length = 6, choices = COLOR_CHOICES, default='green')
  
class MyModel2(models.Model):
  food = models.ForeignKey(MyModel, on_delete=models.CASCADE)
