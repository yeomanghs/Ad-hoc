from django.urls import path

from . import views

urlpatterns = [
#path('', views.CreateMyModelView.as_view()),
    path('', views.CreateMyModelView, name = 'test'),
    path('choice', views.LoadFood, name = 'food')
]