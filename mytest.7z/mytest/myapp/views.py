from django.shortcuts import render
from django.http import HttpResponse
from django.views.generic import ListView, CreateView, UpdateView
from .models import MyModel
from .forms import MyModelForm

# def index(request):
#     return HttpResponse("Hello, world. You're at the polls index.")
# # Create your views here.

# class CreateMyModelView(CreateView):
#     model = MyModel
    #form_class = MyModelForm
    #template_name = 'home.html'
def CreateMyModelView(request):
    model = MyModel
    form_class = MyModelForm
    field_names = [i.name for i in model._meta.get_fields()]
    data = [[1], [2]]
    content = {"colnames": field_names, "dataVal":data}
    return render(request, 'home.html', content)
